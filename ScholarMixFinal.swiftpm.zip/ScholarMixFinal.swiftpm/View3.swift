import Foundation
import SwiftUI

struct View3: View {
    var body: some View {
        ZStack {
            Image("profile")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400, height: 400)
            //.cornerRadius(10)
            VStack {
                //Text("Test")
            }
        }
    }
}
