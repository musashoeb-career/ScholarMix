import Foundation
import SwiftUI

struct View2: View {
    let matches = matchList
    var body: some View {
        NavigationView {
            List {
                Section {
                    ForEach(matches, id: \.self) {match in
                        NavigationLink(destination:
                                        Image("bokujo").resizable().frame(width: 350.0, height: 350.0)   )
                            {
                            Image(userPicture[match] ?? "default.jpg")
                                .resizable()
                                .frame(width: 70, height: 70)
                                //.aspectRatio(contentMode: .fit)
                                .clipShape(Circle())

                            Text(match)
                                .font(.system(size: 20, weight: .bold))
                        }
                        .padding(.vertical, 30)
                    }
                    .background(Color(hue: 0.275, saturation: 0.164, brightness: 0.822))
                    .cornerRadius(10)
                }
            }
            
            .navigationTitle("Messages")
                        .navigationBarTitleDisplayMode(.inline)

        }
    }
}
