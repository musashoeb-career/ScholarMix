//
//  MatchConvos.swift
//  ScholarMix
//
//  Created by meher on 10/21/23.
//

import Foundation

let matchList = [
    "Jodi",
    "Musa",
    "Fatima",
    "Meher"
]

let userPicture: [String:String] = [
    "Jodi": "taylor",
    "Musa": "beaba",
    "Fatima": "lana",
    "Meher": "soobin"
]

let userText: [String:[String:String]] = [
    "Jodi": ["taylor": "hi, we should study again!"],
    "Musa": ["beaba": "helloooo"],
    "Fatima": ["lana": "shlay"],
    "Meher": ["soobin": "study sesh?"]
]
